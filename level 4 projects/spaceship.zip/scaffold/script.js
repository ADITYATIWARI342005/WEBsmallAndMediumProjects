const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const hitSound = document.getElementById("hitSound");
const groundSound = document.getElementById("groundSound");

//Write the javascript here