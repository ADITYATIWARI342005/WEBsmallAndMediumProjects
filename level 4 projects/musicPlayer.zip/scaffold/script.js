// Write your javascript here

    tracks = [
        {
            name: "Let me down slowly",
            artist: "Alec Benjamin",
            cover: "alec.jpg",
            source: "Let me down slowly.mp3",
        },
        {
            name: "Let me love you",
            artist: "DJ Snake/Justin Beiber",
            cover: "dj.jpg",
            source: "Let me love you.mp3",
        },
        {
            name: "Perfect",
            artist: "Ed Sheeran",
            cover: "ed.jpg",
            source: "Perfect.mp3",
        },
        
    ];


